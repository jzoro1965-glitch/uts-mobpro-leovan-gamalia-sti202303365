import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Untuk SystemChrome
import 'models/journal_entry.dart';
import 'services/data_service.dart';
import 'pages/home_page.dart';
import 'pages/add_note_page.dart';
import 'pages/gallery_page.dart';

void main() {
  // Pastikan widget Flutter siap sebelum menjalankan aplikasi
  WidgetsFlutterBinding.ensureInitialized();
  // Mengatur warna bar notifikasi (biar serasi dengan tema)
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent, // Transparan
      statusBarIconBrightness: Brightness.dark, // Ikon gelap
    ),
  );
  runApp(const PersonalJournalApp());
}

class PersonalJournalApp extends StatelessWidget {
  const PersonalJournalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Personal Journal',
      theme: ThemeData(
        // Tema Utama
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue.shade700,
          primary: Colors.blue.shade700,
          secondary: Colors.teal,
        ),
        useMaterial3: true,
        // Styling AppBar
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.blue.shade700,
          foregroundColor: Colors.white,
          elevation: 2,
        ),
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  List<JournalEntry> _journalEntries = [];
  final DataService _dataService = DataService();
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  // === FUNGSI MANAJEMEN DATA ===
  Future<void> _loadData() async {
    final loadedEntries = await _dataService.loadEntries();
    setState(() {
      // Mengurutkan data terbaru di atas
      _journalEntries = loadedEntries;
      _isLoading = false;
    });
  }

  Future<void> _addEntry(JournalEntry entry) async {
    setState(() {
      _journalEntries.insert(0, entry); // Tambahkan di posisi pertama (terbaru)
    });
    await _dataService.saveEntries(_journalEntries);
  }

  Future<void> _deleteEntry(String id) async {
    setState(() {
      _journalEntries.removeWhere((entry) => entry.id == id);
    });
    await _dataService.saveEntries(_journalEntries);
    // Berikan feedback setelah menghapus
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Catatan berhasil dihapus!')),
      );
    }
  }
  // ===============================

  // Fungsi navigasi Bottom Bar
  void _onItemTapped(int index) {
    // Index 1 di-skip karena kita menggunakan FAB untuk "Tambah"
    if (index != 1) {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  // Menangani penambahan catatan melalui FAB
  Future<void> _handleAddNewNote() async {
    final result = await Navigator.push<JournalEntry>(
      context,
      MaterialPageRoute(
        builder: (context) => const AddNotePage(),
      ),
    );

    if (result != null) {
      await _addEntry(result);

      // Feedback success setelah data ditambahkan
      if (mounted) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('Catatan berhasil ditambahkan!', style: TextStyle(color: Colors.white)),
              backgroundColor: Colors.teal.shade700, // Warna sukses yang menarik
              behavior: SnackBarBehavior.floating,
            ),
          );
        });
      }

      // Setelah menambah, arahkan kembali ke Home (index 0)
      setState(() {
        _selectedIndex = 0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Definisi halaman untuk Body
    final List<Widget> pages = <Widget>[
      HomePage(
        entries: _journalEntries,
        onDelete: _deleteEntry,
      ),
      // Index 1 tidak digunakan, diisi placeholder
      Container(key: const ValueKey<int>(1)),
      GalleryPage(
        entries: _journalEntries,
      ),
    ];

    // Mengganti App Bar di MainScreen agar lebih sesuai untuk Bottom Nav Bar
    String titleText = _selectedIndex == 0
        ? 'Catatan Harian'
        : (_selectedIndex == 2 ? 'Galeri Foto' : 'Personal Journal');

    // Menangani aksi App Bar (Menu Opsi)
    List<Widget> appBarActions = [];
    if (_selectedIndex == 0) {
      appBarActions.add(
        PopupMenuButton<String>(
          onSelected: (String result) {
            // TODO: Implementasi logika Sort atau Filter
          },
          itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
            const PopupMenuItem<String>(
              value: 'sort_newest',
              child: Text('Urutkan: Terbaru'),
            ),
            const PopupMenuItem<String>(
              value: 'sort_oldest',
              child: Text('Urutkan: Terlama'),
            ),
          ],
          icon: const Icon(Icons.sort),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(titleText),
        actions: appBarActions,
        // Tidak perlu Leading/Menu, fokus pada navigasi bottom
      ),

      // 🛑 PERSYARATAN UTAMA: AnimatedSwitcher untuk transisi
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : AnimatedSwitcher(
        duration: const Duration(milliseconds: 400),
        switchInCurve: Curves.easeInOut,
        switchOutCurve: Curves.easeInOut,
        transitionBuilder: (Widget child, Animation<double> animation) {
          // Memberi efek fade and slide ringan
          return FadeTransition(
            opacity: animation,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.1, 0), // Mulai dari kanan sedikit
                end: Offset.zero,
              ).animate(animation),
              child: child,
            ),
          );
        },
        child: pages[_selectedIndex],
        key: ValueKey<int>(_selectedIndex), // Kunci penting untuk AnimatedSwitcher
      ),

      // 🛑 PERSYARATAN UTAMA: FloatingActionButton
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _handleAddNewNote,
        icon: const Icon(Icons.add),
        label: const Text('Tambah Catatan'), // FAB.extended lebih informatif
        backgroundColor: Theme.of(context).colorScheme.secondary, // Menggunakan warna sekunder (teal)
        foregroundColor: Colors.white,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked, // Pindah ke tengah bawah

      // 🛑 PERSYARATAN UTAMA: BottomNavigationBar (Minimal 3 Tab)
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.edit_note), // Placeholder untuk FAB
            label: 'Tambah',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.photo_library),
            label: 'Galeri',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Theme.of(context).colorScheme.primary, // Warna saat aktif
        unselectedItemColor: Colors.grey.shade600,
        onTap: _onItemTapped,
        // Menambahkan type: BottomNavigationBarType.fixed jika FAB.extended digunakan
        type: BottomNavigationBarType.fixed,
      ),
    );
  }
}