// File: lib/pages/gallery_page.dart

import 'package:flutter/material.dart';
import 'dart:io';
import '../models/journal_entry.dart';

class GalleryPage extends StatelessWidget {
  final List<JournalEntry> entries;

  const GalleryPage({super.key, required this.entries});

  @override
  Widget build(BuildContext context) {
    // Filter semua entri yang memiliki foto
    final List<File> photos = entries
        .where((e) => e.photo != null)
        .map((e) => e.photo!)
        .toList();

    if (photos.isEmpty) {
      return const Center(
          child: Text('Belum ada foto yang ditambahkan ke catatan.'));
    }

    // Poin 1a: GridView.builder untuk tampilan galeri
    return GridView.builder(
      padding: const EdgeInsets.all(8),
      // GridDelegate menentukan layout grid (3 kolom)
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3, // Jumlah kolom
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: photos.length,
      itemBuilder: (context, index) {
        final photoFile = photos[index];
        // Poin 1a: Container
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            boxShadow: const [
              BoxShadow(
                  color: Colors.black26, offset: Offset(0, 2), blurRadius: 4)
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            // Menampilkan foto dari File (Poin 5a)
            child: Image.file(
              photoFile,
              fit: BoxFit.cover,
            ),
          ),
        );
      },
    );
  }
}