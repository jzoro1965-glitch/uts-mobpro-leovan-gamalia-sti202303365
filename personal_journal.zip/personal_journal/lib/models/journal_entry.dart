// File: lib/models/journal_entry.dart

import 'dart:io';
import 'package:flutter/material.dart'; // Import untuk TimeOfDay

class JournalEntry {
  final String id;
  final String activity;
  final String note;
  final DateTime date;
  final TimeOfDay time;
  final File? photo;
  final double? amount; // FIELD UNTUK JUMLAH UANG

  JournalEntry({
    required this.id,
    required this.activity,
    required this.note,
    required this.date,
    required this.time,
    this.photo,
    this.amount, // TAMBAH DI CONSTRUCTOR
  });

  // Konversi ke Map untuk simpan ke file / database
  Map<String, dynamic> toJson() => {
    'id': id,
    'activity': activity,
    'note': note,
    'date': date.toIso8601String(),
    'time': '${time.hour}:${time.minute}',
    'photoPath': photo?.path,
    'amount': amount, // SIMPAN NILAI UANG
  };

  // Konversi dari Map (misal saat baca file)
  static JournalEntry fromJson(Map<String, dynamic> json) {
    List<String> timeParts = (json['time'] as String).split(':');
    return JournalEntry(
      id: json['id'] as String, // Pastikan tipe data sesuai
      activity: json['activity'] as String, // <<< BARIS INI YANG DIKOREKSI
      note: json['note'] as String? ?? '',
      date: DateTime.parse(json['date'] as String),
      time: TimeOfDay(
        hour: int.parse(timeParts[0]),
        minute: int.parse(timeParts[1]),
      ),
      photo: json['photoPath'] != null ? File(json['photoPath'] as String) : null,
      amount: json['amount'] != null ? (json['amount'] as num).toDouble() : null,
    );
  }
}