// File: lib/services/data_service.dart
import 'package:flutter/foundation.dart';
import 'dart:convert';
import 'dart:io'; 
import 'package:path_provider/path_provider.dart';
import '../models/journal_entry.dart'; // Sesuaikan path

class DataService {
  static const _fileName = 'journal_data.json';

  // Mendapatkan path file penyimpanan
  Future<File> _getLocalFile() async {
    // Poin 4b: path_provider
    final directory = await getApplicationDocumentsDirectory();
    return File('${directory.path}/$_fileName');
  }

  // Membaca data dari file (Poin 4c: Data muncul kembali)
  Future<List<JournalEntry>> loadEntries() async {
    try {
      final file = await _getLocalFile();
      if (!await file.exists()) {
        return [];
      }
      final contents = await file.readAsString();
      final List<dynamic> jsonList = jsonDecode(contents);
      return jsonList.map((json) => JournalEntry.fromJson(json)).toList();
    } catch (e) {
     debugPrint('Error loading data: $e');
  return [];
    }
  }

 // Menyimpan data ke file (Poin 4b: File I/O)
Future<void> saveEntries(List<JournalEntry> entries) async {
  try {
    final file = await _getLocalFile();
    final jsonList = entries.map((e) => e.toJson()).toList();
    await file.writeAsString(jsonEncode(jsonList));
  } catch (e) {
    debugPrint('Error saving data: $e'); //  ganti print() → debugPrint()
  }
}
}