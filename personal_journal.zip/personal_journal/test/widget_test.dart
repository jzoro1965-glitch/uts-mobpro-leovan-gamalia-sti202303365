// File: lib/widget_test.dart

// Ini adalah tes widget dasar yang memastikan aplikasi dapat dimuat
// tanpa crash, dan komponen utama seperti AppBar muncul.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

// [1] Impor kelas utama yang benar dari main.dart
import 'package:personal_journal/main.dart'; 

void main() {
  // [2] Ganti nama tes agar sesuai dengan aplikasi Personal Journal
  testWidgets('Aplikasi Personal Journal dapat dimuat', (WidgetTester tester) async {
    
    // [3] Ganti MyApp() menjadi PersonalJournalApp()
    await tester.pumpWidget(const PersonalJournalApp()); 

    // Verifikasi bahwa aplikasi dimuat.
    // Kita cek apakah AppBar dengan judul 'Personal Journal' muncul.
    expect(find.text('Personal Journal'), findsOneWidget); 
    
    // Verifikasi bahwa BottomNavigationBar memiliki 3 item.
    expect(find.byIcon(Icons.home), findsOneWidget);
    expect(find.byIcon(Icons.edit_note), findsOneWidget);
    expect(find.byIcon(Icons.photo_library), findsOneWidget);
    
    // Verifikasi bahwa FloatingActionButton untuk menambah catatan muncul.
    expect(find.byIcon(Icons.add), findsOneWidget);
  });
}