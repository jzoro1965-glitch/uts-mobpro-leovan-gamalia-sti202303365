// File: lib/models/journal_entry.dart

import 'dart:io';
import 'package:flutter/material.dart'; // Import ini untuk TimeOfDay

class JournalEntry {
  final String id;
  final String activity;
  final DateTime date;
  final TimeOfDay time;
  final File? photo; // path File untuk foto

  JournalEntry({
    required this.id,
    required this.activity,
    required this.date,
    required this.time,
    this.photo,
  });

  // Konversi ke Map untuk keperluan File I/O
  Map<String, dynamic> toJson() => {
        'id': id,
        'activity': activity,
        'date': date.toIso8601String(),
        'time': '${time.hour}:${time.minute}',
        'photoPath': photo?.path,
      };

  // Konversi dari Map untuk keperluan File I/O
  static JournalEntry fromJson(Map<String, dynamic> json) {
    List<String> timeParts = (json['time'] as String).split(':');
    return JournalEntry(
      id: json['id'],
      activity: json['activity'],
      date: DateTime.parse(json['date']),
      time: TimeOfDay(
          hour: int.parse(timeParts[0]), minute: int.parse(timeParts[1])),
      photo: json['photoPath'] != null ? File(json['photoPath']) : null,
    );
  }
}