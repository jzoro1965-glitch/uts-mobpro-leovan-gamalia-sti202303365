package com.example.personal_journal

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
