import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'models/journal_entry.dart';
import 'services/data_service.dart';
import 'pages/home_page.dart';
import 'pages/add_note_page.dart';
import 'pages/gallery_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('id_ID', null); // Locale Indonesia untuk tanggal
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );
  runApp(const PersonalJournalApp());
}

class PersonalJournalApp extends StatelessWidget {
  const PersonalJournalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Personal Journal',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue.shade700,
          primary: Colors.blue.shade700,
          secondary: Colors.teal,
        ),
        useMaterial3: true,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.blue.shade700,
          foregroundColor: Colors.white,
          elevation: 2,
        ),
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0; // 0 = Home, 1 = Galeri (indeks yang sudah dikoreksi)
  List<JournalEntry> _journalEntries = [];
  final DataService _dataService = DataService();
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final loadedEntries = await _dataService.loadEntries();
    setState(() {
      _journalEntries = loadedEntries;
      _isLoading = false;
    });
  }

  Future<void> _addEntry(JournalEntry entry) async {
    setState(() {
      _journalEntries.insert(0, entry);
    });
    await _dataService.saveEntries(_journalEntries);
  }

  Future<void> _deleteEntry(String id) async {
    setState(() {
      _journalEntries.removeWhere((entry) => entry.id == id);
    });
    await _dataService.saveEntries(_journalEntries);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Catatan berhasil dihapus!')),
      );
    }
  }

  void _onItemTapped(int index) {
    // Jika tombol tengah (index 1) diklik, jangan ubah _selectedIndex
    if (index != 1) {
      // Mapping index: 0 (Home) tetap 0, 2 (Galeri) menjadi 1
      setState(() => _selectedIndex = index == 2 ? 1 : 0);
    }
  }

  Future<void> _handleAddNewNote() async {
    final result = await Navigator.push<JournalEntry>(
      context,
      MaterialPageRoute(builder: (context) => const AddNotePage()),
    );

    if (result != null) {
      await _addEntry(result);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Catatan berhasil ditambahkan!'),
            backgroundColor:
            Theme.of(context).colorScheme.secondary.withOpacity(0.9),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
      setState(() => _selectedIndex = 0);
    }
  }

  @override
  Widget build(BuildContext context) {
    // pages kini menggunakan indeks 0 dan 1
    final List<Widget> pages = [
      HomePage(entries: _journalEntries, onDelete: _deleteEntry),
      GalleryPage(entries: _journalEntries),
    ];

    // Mengubah indeks 1 menjadi 2 untuk tampilan bottom nav
    final bool isHomeSelected = _selectedIndex == 0;
    final String titleText = isHomeSelected ? 'Catatan Harian' : 'Galeri Foto';

    // appBarActions sekarang bertipe List<Widget>
    final List<Widget> appBarActions = isHomeSelected
        ? <Widget>[ // Tipe data List<Widget> eksplisit
      PopupMenuButton<String>(
        onSelected: (String result) {
          if (result == 'sort_newest') {
            setState(() => _journalEntries.sort(
                    (a, b) => b.date.compareTo(a.date))); // Terbaru
          } else if (result == 'sort_oldest') {
            setState(() => _journalEntries.sort(
                    (a, b) => a.date.compareTo(b.date))); // Terlama
          }
        },
        itemBuilder: (context) => const [
          PopupMenuItem(
              value: 'sort_newest', child: Text('Urutkan: Terbaru')),
          PopupMenuItem(
              value: 'sort_oldest', child: Text('Urutkan: Terlama')),
        ],
        icon: const Icon(Icons.sort),
      ),
    ]
        : [];

    return Scaffold(
      // === BARIS DIKOREKSI ===
      // Menggunakan .cast<Widget>() untuk mengatasi error tipe data
      appBar: AppBar(title: Text(titleText), actions: appBarActions.cast<Widget>().toList()),
      // ========================
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : AnimatedSwitcher(
        duration: const Duration(milliseconds: 400),
        switchInCurve: Curves.easeInOut,
        transitionBuilder: (child, animation) => FadeTransition(
          opacity: animation,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0.1, 0),
              end: Offset.zero,
            ).animate(animation),
            child: child,
          ),
        ),
        // Menggunakan _selectedIndex (0 atau 1) untuk mengakses pages
        child: pages[_selectedIndex],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _handleAddNewNote,
        icon: const Icon(Icons.add),
        label: const Text('Tambah Catatan'),
        backgroundColor: Theme.of(context).colorScheme.secondary,
        foregroundColor: Colors.white,
        elevation: 6,
      ),
      floatingActionButtonLocation:
      FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(),
        notchMargin: 6,
        elevation: 8,
        color: Theme.of(context).colorScheme.surface,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            IconButton(
              icon: const Icon(Icons.home),
              // Cek dengan _selectedIndex == 0
              color: isHomeSelected
                  ? Theme.of(context).colorScheme.primary
                  : Colors.grey.shade600,
              onPressed: () => _onItemTapped(0),
              tooltip: 'Home',
            ),
            const SizedBox(width: 40),
            IconButton(
              icon: const Icon(Icons.photo_library),
              // Cek dengan _selectedIndex == 1
              color: _selectedIndex == 1
                  ? Theme.of(context).colorScheme.primary
                  : Colors.grey.shade600,
              onPressed: () => _onItemTapped(2), // Tetap kirim 2, di _onItemTapped akan diubah ke 1
              tooltip: 'Galeri',
            ),
          ],
        ),
      ),
    );
  }
}