import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb; // Impor untuk mendeteksi platform web
import 'dart:io';
import '../models/journal_entry.dart';

class GalleryPage extends StatelessWidget {
  final List<JournalEntry> entries;

  const GalleryPage({super.key, required this.entries});

  // Widget pembantu untuk menampilkan foto dengan penanganan platform
  Widget _buildImage(File photoFile) {
    // Cek apakah aplikasi sedang berjalan di Flutter Web
    if (kIsWeb) {
      // Di Web, kita tidak bisa menggunakan Image.file. 
      // Kita tampilkan Placeholder atau ikon untuk mencegah error "merah"
      return Container(
        color: Colors.grey[300], // Warna abu-abu sebagai placeholder
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.image_not_supported,
                size: 30,
                color: Colors.grey,
              ),
              const SizedBox(height: 4),
              Text(
                'Web Preview',
                style: TextStyle(color: Colors.grey[600], fontSize: 10),
              ),
            ],
          ),
        ),
      );
    } else {
      // Di Mobile (Android/iOS), kita bisa menggunakan Image.file
      return Image.file(
        photoFile,
        fit: BoxFit.cover,
        // Tambahkan errorBuilder untuk jaga-jaga jika file tidak ditemukan
        errorBuilder: (context, error, stackTrace) {
          return const Center(
            child: Icon(Icons.broken_image, color: Colors.red),
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Filter semua entri yang memiliki foto
    final List<File> photos = entries
        .where((e) => e.photo != null)
        .map((e) => e.photo!)
        .toList();

    if (photos.isEmpty) {
      return const Center(
          child: Text('Belum ada foto yang ditambahkan ke catatan.'));
    }

    // Poin 1a: GridView.builder untuk tampilan galeri
    return GridView.builder(
      padding: const EdgeInsets.all(8),
      // GridDelegate menentukan layout grid (3 kolom)
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3, // Jumlah kolom
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: photos.length,
      itemBuilder: (context, index) {
        final photoFile = photos[index];
        // Poin 1a: Container
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            boxShadow: const [
              BoxShadow(
                  color: Colors.black26, offset: Offset(0, 2), blurRadius: 4)
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            // Menggunakan widget pembantu yang sudah menangani platform
            child: _buildImage(photoFile),
          ),
        );
      },
    );
  }
}
