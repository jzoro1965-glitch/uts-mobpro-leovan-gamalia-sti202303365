// File: lib/pages/home_page.dart

import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/journal_entry.dart';
// import detail_page.dart jika ada
// import 'detail_page.dart'; 

class HomePage extends StatelessWidget {
  final List<JournalEntry> entries;
  final Function(String) onDelete;

  const HomePage({
    super.key,
    required this.entries,
    required this.onDelete,
  });

  // Widget saat daftar catatan kosong
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Icon(
            Icons.book_outlined,
            size: 80,
            color: Colors.grey.shade300,
          ),
          const SizedBox(height: 15),
          Text(
            'Catatan Harian Anda Kosong',
            style: TextStyle(
              fontSize: 20,
              color: Colors.grey.shade600,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            'Tekan tombol "Tambah Catatan" di bawah untuk memulai.',
            style: TextStyle(color: Colors.grey.shade500),
          ),
        ],
      ),
    );
  }

  // Widget untuk menampilkan setiap item jurnal
  Widget _buildEntryItem(BuildContext context, JournalEntry entry) {
    // Penanganan gambar untuk Web atau Mobile
    Widget imageWidget;
    if (entry.photo != null) {
      if (kIsWeb) {
        imageWidget = Image.network(entry.photo!.path, fit: BoxFit.cover);
      } else {
        // Penting: Pastikan 'File' diimport dari 'dart:io' jika menggunakan Image.file
        // dan pastikan file exists, jika tidak gunakan placeholder
        try {
          if (File(entry.photo!.path).existsSync()) {
            imageWidget = Image.file(File(entry.photo!.path), fit: BoxFit.cover);
          } else {
            imageWidget = const Icon(Icons.broken_image, size: 40);
          }
        } catch (e) {
          imageWidget = const Icon(Icons.photo_album, size: 40, color: Colors.blueGrey);
        }
      }
    } else {
      imageWidget = const Icon(Icons.article, size: 40, color: Colors.blueGrey);
    }

    return Card(
      elevation: 4, // Memberi bayangan agar menonjol
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () {
          // TODO: Navigasi ke Detail Page jika ada
          // Navigator.push(context, MaterialPageRoute(builder: (context) => DetailPage(entry: entry)));
        },
        child: ListTile(
          contentPadding: const EdgeInsets.all(12),

          // Gambar atau ikon di sebelah kiri
          leading: Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              color: Colors.grey.shade200,
            ),
            clipBehavior: Clip.antiAlias,
            child: imageWidget,
          ),

          // Judul (Aktivitas)
          title: Text(
            entry.activity,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),

          // Subtitle (Tanggal dan Waktu)
          subtitle: Text(
            '${DateFormat('EEEE, dd MMM yyyy').format(entry.date)} Pukul ${entry.time.format(context)}',
            style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
          ),

          // 🛑 PERSYARATAN UTS: PopupMenu untuk Edit/Hapus
          trailing: PopupMenuButton<String>(
            onSelected: (String result) {
              if (result == 'delete') {
                onDelete(entry.id); // Panggil fungsi hapus
              }
              // TODO: Tambahkan fungsi 'edit' jika sudah diimplementasi
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              const PopupMenuItem<String>(
                value: 'edit',
                child: Text('Edit Catatan'),
              ),
              const PopupMenuItem<String>(
                value: 'delete',
                child: Text('Hapus Catatan', style: TextStyle(color: Colors.red)),
              ),
            ],
            icon: const Icon(Icons.more_vert),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) {
      return _buildEmptyState();
    }

    // Gunakan ListView.builder untuk daftar yang efisien
    return ListView.builder(
      padding: const EdgeInsets.only(top: 10, bottom: 80), // Padding bawah untuk FAB
      itemCount: entries.length,
      itemBuilder: (context, index) {
        return _buildEntryItem(context, entries[index]);
      },
    );
  }
}