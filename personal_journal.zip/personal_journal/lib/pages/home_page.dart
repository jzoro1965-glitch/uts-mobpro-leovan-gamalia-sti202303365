import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/journal_entry.dart';

// =========================================================================
// POPUP DETAIL CARD
// =========================================================================
class DetailCardDialog extends StatelessWidget {
  final JournalEntry entry;
  const DetailCardDialog({super.key, required this.entry});

  @override
  Widget build(BuildContext context) {
    final formattedAmount = entry.amount != null && entry.amount! > 0
        ? NumberFormat.currency(locale: 'id', symbol: 'Rp', decimalDigits: 0)
        .format(entry.amount)
        : 'Tidak Ada Transaksi';

    // Widget Gambar
    Widget imageWidget;
    if (entry.photo != null) {
      if (kIsWeb) {
        imageWidget = Image.network(
          entry.photo!.path,
          fit: BoxFit.cover,
          width: double.infinity,
          height: 220,
        );
      } else {
        try {
          if (File(entry.photo!.path).existsSync()) {
            imageWidget = Image.file(
              File(entry.photo!.path),
              fit: BoxFit.cover,
              width: double.infinity,
              height: 220,
            );
          } else {
            imageWidget = Container(
              width: double.infinity,
              height: 220,
              color: Colors.grey.shade200,
              child:
              const Icon(Icons.broken_image, size: 60, color: Colors.grey),
            );
          }
        } catch (e) {
          imageWidget = Container(
            width: double.infinity,
            height: 220,
            color: Colors.grey.shade200,
            child: const Icon(Icons.photo, size: 60, color: Colors.grey),
          );
        }
      }
    } else {
      imageWidget = Container(
        width: double.infinity,
        height: 220,
        color: Colors.grey.shade100,
        child: const Icon(Icons.photo, size: 60, color: Colors.grey),
      );
    }

    return Dialog(
      backgroundColor: const Color(0xFFFFF8E1),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 25, vertical: 60),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            child: imageWidget,
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  entry.activity,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 18),
                ),
                const SizedBox(height: 6),
                Text(
                  formattedAmount,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Colors.green,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  entry.note.isNotEmpty ? entry.note : 'Tidak ada catatan.',
                  style:
                  const TextStyle(fontSize: 14, color: Colors.black87),
                ),
                const SizedBox(height: 12),
                Text(
                  DateFormat('EEEE, dd MMM yyyy • HH:mm', 'id_ID')
                      .format(entry.date),
                  style:
                  TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text(
                      "Tutup",
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.blue),
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =========================================================================
// HOME PAGE (SINKRON DENGAN MAIN.DART KAMU)
// =========================================================================
class HomePage extends StatelessWidget {
  final List<JournalEntry> entries;
  final Function(String) onDelete;

  const HomePage({
    super.key,
    required this.entries,
    required this.onDelete,
  });

  // Menampilkan pop-up detail
  void _showDetailPopup(BuildContext context, JournalEntry entry) {
    showDialog(
      context: context,
      builder: (context) => DetailCardDialog(entry: entry),
    );
  }

  // Tampilan kosong
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.book_outlined,
              size: 80, color: Colors.grey.shade300),
          const SizedBox(height: 15),
          Text(
            'Catatan Harian Anda Kosong',
            style: TextStyle(
              fontSize: 20,
              color: Colors.grey.shade600,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            'Tekan tombol "Tambah Catatan" di bawah untuk memulai.',
            style: TextStyle(color: Colors.grey.shade500),
          ),
        ],
      ),
    );
  }

  // Widget untuk tiap item
  Widget _buildEntryItem(BuildContext context, JournalEntry entry) {
    Widget imageWidget;
    if (entry.photo != null) {
      if (kIsWeb) {
        imageWidget = Image.network(entry.photo!.path, fit: BoxFit.cover);
      } else {
        try {
          if (File(entry.photo!.path).existsSync()) {
            imageWidget =
                Image.file(File(entry.photo!.path), fit: BoxFit.cover);
          } else {
            imageWidget =
            const Icon(Icons.broken_image, size: 28, color: Colors.grey);
          }
        } catch (e) {
          imageWidget =
          const Icon(Icons.photo_album, size: 28, color: Colors.blueGrey);
        }
      }
    } else {
      imageWidget =
      const Icon(Icons.article, size: 28, color: Colors.blueGrey);
    }

    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: InkWell(
        onTap: () => _showDetailPopup(context, entry),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Foto
              Container(
                width: 55,
                height: 55,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(55 / 2),
                  color: Colors.grey.shade200,
                ),
                clipBehavior: Clip.antiAlias,
                alignment: Alignment.center,
                child: imageWidget,
              ),
              const SizedBox(width: 15),

              // Teks
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      entry.activity,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 16),
                    ),
                    if (entry.note.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 4.0),
                        child: Text(
                          entry.note,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: Colors.grey.shade600, fontSize: 13),
                        ),
                      ),
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Text(
                        '${DateFormat('EEEE, dd MMM yyyy').format(entry.date)} • ${entry.time.format(context)}',
                        style: TextStyle(
                            color: Colors.grey.shade500, fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),

              // Menu Edit/Hapus
              PopupMenuButton<String>(
                onSelected: (String result) {
                  if (result == 'delete') {
                    onDelete(entry.id);
                  }
                },
                itemBuilder: (context) => [
                  const PopupMenuItem<String>(
                    value: 'delete',
                    child: Text('Hapus Catatan',
                        style: TextStyle(color: Colors.red)),
                  ),
                ],
                icon: const Icon(Icons.more_vert,
                    size: 20, color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) return _buildEmptyState();

    return ListView.builder(
      padding: const EdgeInsets.only(top: 10, bottom: 80),
      itemCount: entries.length,
      itemBuilder: (context, i) => _buildEntryItem(context, entries[i]),
    );
  }
}
